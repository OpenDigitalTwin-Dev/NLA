/******************************************************************************
* Copyright (c) Intel Corporation - All rights reserved.                      *
* This file is part of the LIBXSMM library.                                   *
*                                                                             *
* For information on the license, see the LICENSE file.                       *
* Further information: https://github.com/libxsmm/libxsmm/                    *
* SPDX-License-Identifier: BSD-3-Clause                                       *
******************************************************************************/
/* Hans Pabst (Intel Corp.)
******************************************************************************/
#include <libxsmm_source.h>
#include <algorithm>
#include <stdexcept>
#include <cstdlib>
#include <cstring>
#include <cassert>
#include <cstdio>
#include <cmath>
#if defined(_OPENMP)
# include <omp.h>
#endif

#if 0 /* enable padding on a per-matrix basis */
# define PAD(TYPE, VALUE) (LIBXSMM_UP2((VALUE) * sizeof(TYPE), LIBXSMM_ALIGNMENT) / sizeof(TYPE))
#else
# define PAD(TYPE, VALUE) (VALUE)
#endif

#if !defined(RANDOMIZED) && 0
# define RANDOMIZED
#endif

#if !defined(ITYPE)
# define ITYPE double
#endif
#if !defined(OTYPE)
# define OTYPE ITYPE
#endif


int main(int argc, char* argv[])
{
  int result = EXIT_SUCCESS;
  try {
    const libxsmm_blasint benchmark = (1 < argc ? std::atoi(argv[1]) : 0);
    const libxsmm_blasint m = (2 < argc ? std::atoi(argv[2]) : 23);
    const libxsmm_blasint k = (4 < argc ? std::atoi(argv[4]) : m);
    const libxsmm_blasint n = (3 < argc ? std::atoi(argv[3]) : k);
    const libxsmm_blasint q = (5 < argc ? std::atoi(argv[5]) : 0/*auto*/);
    const libxsmm_blasint nrepeat = ((6 < argc && 0 < std::atoi(argv[6]))
      ? std::atoi(argv[6]) : (0 >= q ? 13 : 1));

    const libxsmm_blasint lda = m, ldb = k, ldc = m;
    const char transa = 'N', transb = 'N';
    const OTYPE alpha = 1, beta = 1;

    const libxsmm_blasint asize = PAD(ITYPE, lda * k), bsize = PAD(ITYPE, ldb * n), csize = PAD(OTYPE, ldc * n);
    const libxsmm_blasint max_size = ((2ULL << 30/*2 GB*/) / ((static_cast<size_t>(asize) + bsize) * sizeof(ITYPE) + csize * sizeof(OTYPE)));
    const libxsmm_blasint s = LIBXSMM_MIN(0 < q ? q : max_size, max_size);
    const libxsmm_blasint aspace = LIBXSMM_ALIGNMENT / sizeof(ITYPE);
    const size_t bwsize = (static_cast<size_t>(asize)/*load*/ + static_cast<size_t>(bsize)/*load*/) * sizeof(ITYPE)
                        + (sizeof(OTYPE) * static_cast<size_t>(csize) * 2/*RFO*/);
    const double gflops = 2E-9 * s * m * n * k;
#if LIBXSMM_TYPEINFO(ITYPE, FP)
    const char ops[] = "FLOPS";
    const double scale = 1.0 / s;
#else
    const char ops[] = "OPS";
    const double scale = 1;
#endif
#if !defined(_DEBUG)
    const char *const env_check = getenv("CHECK");
    const int check = (NULL == env_check ? 0 : atoi(env_check));
#else
    /*const*/ int check = 1;
#endif
#if defined(_OPENMP)
    const libxsmm_blasint chunksize = s / omp_get_max_threads();
#endif
    struct raii { // avoid std::vector (first-touch init. causes NUMA issue)
      ITYPE *a, *b;
      OTYPE *c;
      size_t m_size, m_shuffle;
      raii(libxsmm_blasint asize_, libxsmm_blasint bsize_, libxsmm_blasint csize_, libxsmm_blasint size_)
        : a(new ITYPE[static_cast<size_t>(asize_)]), b(new ITYPE[static_cast<size_t>(bsize_)])
        , c(new OTYPE[static_cast<size_t>(csize_)])
        , m_size(static_cast<size_t>(size_)), m_shuffle(libxsmm_coprime2(static_cast<unsigned int>(size_)))
      {}
      ~raii() { delete[] a; delete[] b; delete[] c; }
#if defined(RANDOMIZED)
      libxsmm_blasint shuffle(libxsmm_blasint i) const { return (i * m_shuffle) % m_size; }
#else
      libxsmm_blasint shuffle(libxsmm_blasint i) const { return i; }
#endif
    } helper(s * asize + aspace - 1, s * bsize + aspace - 1, s * csize + aspace - 1, s);

    ITYPE *const a = LIBXSMM_ALIGN(helper.a, LIBXSMM_ALIGNMENT);
    ITYPE *const b = LIBXSMM_ALIGN(helper.b, LIBXSMM_ALIGNMENT);
    OTYPE *const c = LIBXSMM_ALIGN(helper.c, LIBXSMM_ALIGNMENT);
#if defined(_OPENMP)
#   pragma omp parallel for schedule(static)
#endif
    for (libxsmm_blasint i = 0; i < s; ++i) {
      LIBXSMM_MATINIT(ITYPE, 42 + helper.shuffle(i), a + static_cast<size_t>(asize) * helper.shuffle(i), m, k, lda, scale);
      LIBXSMM_MATINIT(ITYPE, 24 + helper.shuffle(i), b + static_cast<size_t>(bsize) * helper.shuffle(i), k, n, ldb, scale);
      LIBXSMM_MATINIT(OTYPE, 22 + i, c + static_cast<size_t>(csize) * i, m, n, ldc, scale);
    }

    // initialize LIBXSMM
    libxsmm_init();

    fprintf(stdout, "m=%lli n=%lli k=%lli size=%lli memory=%.1f MB (input=%s output=%s)\n\n",
      static_cast<long long>(m), static_cast<long long>(n), static_cast<long long>(k), static_cast<long long>(s),
      1.0 * (s * ((static_cast<size_t>(asize) + bsize) * sizeof(ITYPE) + csize * sizeof(OTYPE))) / (1ULL << 20),
      LIBXSMM_TYPENAME(ITYPE), LIBXSMM_TYPENAME(OTYPE));

    switch (benchmark) {
    case 0: { // batched
      fprintf(stdout, "Batched (A,B,C)...\n");
      const libxsmm_timer_tickint start = libxsmm_timer_tick();
      for (libxsmm_blasint r = 0; r < nrepeat; ++r) {
#if defined(_OPENMP)
#       pragma omp parallel for schedule(static)
#endif
        for (libxsmm_blasint i = 0; i < s; ++i) {
          LIBXSMM_INLINE_XGEMM(ITYPE, OTYPE, &transa, &transb, &m, &n, &k,
            &alpha, a + static_cast<size_t>(asize) * helper.shuffle(i), &lda, b + static_cast<size_t>(bsize) * helper.shuffle(i), &ldb,
              &beta, c + static_cast<size_t>(csize) * i, &ldc);
        }
      }
      const libxsmm_timer_tickint ncycles = libxsmm_timer_ncycles(start, libxsmm_timer_tick());
      const double duration = libxsmm_timer_duration(0, ncycles) / nrepeat;
      if (0 < duration && 0 != ncycles) {
        fprintf(stdout, "\tpseudo-perf.: %.1f %s/cycle\n", (2.0 * k - 1.0) * (static_cast<double>(s) * m * n) / ncycles, ops);
        fprintf(stdout, "\tperformance: %.1f G%s/s\n", gflops / duration, ops);
        fprintf(stdout, "\tbandwidth: %.1f GB/s\n", s * bwsize / (duration * (1ULL << 30)));
      }
      fprintf(stdout, "\tduration: %.0f ms\n", 1000.0 * duration);
    } break;

    case 1: { // streaming A and C
      fprintf(stdout, "Streamed (A,C)...\n");
      const libxsmm_timer_tickint start = libxsmm_timer_tick();
      for (libxsmm_blasint r = 0; r < nrepeat; ++r) {
#if defined(_OPENMP)
#       pragma omp parallel for schedule(static)
#endif
        for (libxsmm_blasint i = 0; i < s; ++i) {
          LIBXSMM_INLINE_XGEMM(ITYPE, OTYPE, &transa, &transb, &m, &n, &k,
            &alpha, a + static_cast<size_t>(asize) * helper.shuffle(i), &lda, b, &ldb,
              &beta, c + static_cast<size_t>(csize) * i, &ldc);
        }
      }
      const libxsmm_timer_tickint ncycles = libxsmm_timer_ncycles(start, libxsmm_timer_tick());
      const double duration = libxsmm_timer_duration(0, ncycles) / nrepeat;
      if (0 < duration && 0 != ncycles) {
        fprintf(stdout, "\tpseudo-perf.: %.1f %s/cycle\n", (2.0 * k - 1.0) * (static_cast<double>(s) * m * n) / ncycles, ops);
        fprintf(stdout, "\tperformance: %.1f G%s/s\n", gflops / duration, ops);
        fprintf(stdout, "\tbandwidth: %.1f GB/s\n", s * (bwsize - bsize * sizeof(ITYPE)) / (duration * (1ULL << 30)));
      }
      fprintf(stdout, "\tduration: %.0f ms\n", 1000.0 * duration);
    } break;

    case 2: { // streaming B and C
      fprintf(stdout, "Streamed (B,C)...\n");
      const libxsmm_timer_tickint start = libxsmm_timer_tick();
      for (libxsmm_blasint r = 0; r < nrepeat; ++r) {
#if defined(_OPENMP)
#       pragma omp parallel for schedule(static)
#endif
        for (libxsmm_blasint i = 0; i < s; ++i) {
          LIBXSMM_INLINE_XGEMM(ITYPE, OTYPE, &transa, &transb, &m, &n, &k,
            &alpha, a, &lda, b + static_cast<size_t>(bsize) * helper.shuffle(i), &ldb,
              &beta, c + static_cast<size_t>(csize) * i, &ldc);
        }
      }
      const libxsmm_timer_tickint ncycles = libxsmm_timer_ncycles(start, libxsmm_timer_tick());
      const double duration = libxsmm_timer_duration(0, ncycles) / nrepeat;
      if (0 < duration && 0 != ncycles) {
        fprintf(stdout, "\tpseudo-perf.: %.1f %s/cycle\n", (2.0 * k - 1.0) * (static_cast<double>(s) * m * n) / ncycles, ops);
        fprintf(stdout, "\tperformance: %.1f G%s/s\n", gflops / duration, ops);
        fprintf(stdout, "\tbandwidth: %.1f GB/s\n", s * (bwsize - asize * sizeof(ITYPE)) / (duration * (1ULL << 30)));
      }
      fprintf(stdout, "\tduration: %.0f ms\n", 1000.0 * duration);
    } break;

    case 3: { // streaming A and B
      fprintf(stdout, "Streamed (A,B)...\n");
      const libxsmm_timer_tickint start = libxsmm_timer_tick();
      for (libxsmm_blasint r = 0; r < nrepeat; ++r) {
#if defined(_OPENMP)
#       pragma omp parallel for schedule(static)
#endif
        for (libxsmm_blasint i = 0; i < s; ++i) {
#if defined(_OPENMP) /* attempt to write to disjunct cachelines */
          const libxsmm_blasint j = omp_get_thread_num() * chunksize * csize;
#else
          const libxsmm_blasint j = 0;
#endif
          LIBXSMM_INLINE_XGEMM(ITYPE, OTYPE, &transa, &transb, &m, &n, &k,
            &alpha, a + static_cast<size_t>(asize) * helper.shuffle(i), &lda, b + static_cast<size_t>(bsize) * helper.shuffle(i), &ldb,
              &beta, c + j, &ldc);
        }
      }
      const libxsmm_timer_tickint ncycles = libxsmm_timer_ncycles(start, libxsmm_timer_tick());
      const double duration = libxsmm_timer_duration(0, ncycles) / nrepeat;
      if (0 < duration && 0 != ncycles) {
        fprintf(stdout, "\tpseudo-perf.: %.1f %s/cycle\n", (2.0 * k - 1.0) * (static_cast<double>(s) * m * n) / ncycles, ops);
        fprintf(stdout, "\tperformance: %.1f G%s/s\n", gflops / duration, ops);
        fprintf(stdout, "\tbandwidth: %.1f GB/s\n", s * (bwsize - sizeof(OTYPE) * csize * 2) / (duration * (1ULL << 30)));
      }
      fprintf(stdout, "\tduration: %.0f ms\n", 1000.0 * duration);
    } break;

    case 4: { // cached
      fprintf(stdout, "Cached...\n");
      const libxsmm_timer_tickint start = libxsmm_timer_tick();
      for (libxsmm_blasint r = 0; r < nrepeat; ++r) {
#if defined(_OPENMP)
#       pragma omp parallel for schedule(static)
#endif
        for (libxsmm_blasint i = 0; i < s; ++i) {
#if defined(_OPENMP) /* attempt to write to disjunct cachelines */
          const libxsmm_blasint j = omp_get_thread_num() * chunksize * csize;
#else
          const libxsmm_blasint j = 0;
#endif
          LIBXSMM_INLINE_XGEMM(ITYPE, OTYPE, &transa, &transb, &m, &n, &k,
            &alpha, a, &lda, b, &ldb,
              &beta, c + j, &ldc);
        }
      }
      const libxsmm_timer_tickint ncycles = libxsmm_timer_ncycles(start, libxsmm_timer_tick());
      const double duration = libxsmm_timer_duration(0, ncycles) / nrepeat;
      if (0 < duration && 0 != ncycles) {
        fprintf(stdout, "\tpseudo-perf.: %.1f %s/cycle\n", (2.0 * k - 1.0) * (static_cast<double>(s) * m * n) / ncycles, ops);
        fprintf(stdout, "\tperformance: %.1f G%s/s\n", gflops / duration, ops);
      }
      fprintf(stdout, "\tduration: %.0f ms\n", 1000.0 * duration);
    } break;
    default: throw "invalid case selected!";
    } /*switch*/

    if (0 != check) {
      libxsmm_matdiff_info diff;
      result = libxsmm_matdiff(&diff, LIBXSMM_DATATYPE(OTYPE), m, n, c, NULL, &ldc, &ldc);
      if (EXIT_SUCCESS == result) {
        fprintf(stdout, "\tcheck: %f\n", diff.l1_ref);
      }
    }
    // finalize LIBXSMM
    libxsmm_finalize();
    fprintf(stdout, "Finished\n");
  }
  catch(const std::exception& e) {
    fprintf(stderr, "Error: %s\n", e.what());
    result = EXIT_FAILURE;
  }
  catch(const char* message) {
    fprintf(stderr, "Error: %s\n", message);
    result = EXIT_FAILURE;
  }
  catch(...) {
    fprintf(stderr, "Error: unknown exception caught!\n");
    result = EXIT_FAILURE;
  }

  return result;
}
